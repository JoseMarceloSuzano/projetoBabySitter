package Models;

import java.util.ArrayList;
import java.util.Scanner;

public class Equipamentos {
	
	private String DescriçãoDoEquipamento;
	private int QuantidadeDoEquipamento; 
	
	public Equipamentos() {		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Descrição do Equipamento: ");
		this.DescriçãoDoEquipamento = input.nextLine();
		
		System.out.print("Quantidade Do Equipamento:  ");
		this.QuantidadeDoEquipamento = input.nextInt();		
		
		System.out.println("Cadastro realizado com sucesso.");
		
	}

	public String toString() {
		return "\nDescrição do Equipamento: " + this.DescriçãoDoEquipamento + "\nQuantidade do Emquipamento: " + this.QuantidadeDoEquipamento;
	}
	
}
