package Models;

import java.util.Scanner;

public class Baba {
	
	private String Nome;
	private String CPF;
	private int Idade;
	private String Telefone;
	private String Endereco;
	private String Email;
	private String Escolaridade;
	private String TituloDeEleitor;
	private String Antecedentes;
	private String Qualificacoes;
	private String Experiencia;
	private Double Disponibilidade;
	private int LimitesDeCriancas; 
	private String Observacoes;

	public Baba() {
		Scanner input = new Scanner(System.in);
		
		System.out.print("nome: ");
		this.Nome = input.nextLine();
		
		System.out.print("CPF: ");
		this.CPF = input.nextLine();
		
		System.out.print("Idade: ");
		this.Idade = input.nextInt();
		input.nextLine();
		
		System.out.print("Telefone: ");
		this.Telefone = input.nextLine();
		
		System.out.print("Endereço: ");
		this.Endereco = input.nextLine();
		
		System.out.print("Email: ");
		this.Email = input.nextLine();
		
		System.out.print("Escolaridade: ");
		this.Escolaridade = input.nextLine();
		
		System.out.print("Título de Eleitor: ");
		this.TituloDeEleitor = input.nextLine();
		
		System.out.print("Antecedentes: ");
		this.Antecedentes = input.nextLine();
		
		System.out.print("Qualificações: ");
		this.Qualificacoes = input.nextLine();
		
		System.out.print("Experiencias: ");
		this.Experiencia = input.nextLine();
		
		System.out.print("Disponibilidade em Horas: ");
		this.Disponibilidade = input.nextDouble();
		input.nextLine();
		
		System.out.print("Limite de crianças que ela poderá tomar conta: ");
		this.LimitesDeCriancas = input.nextInt();
		input.nextLine();
		
		System.out.print("Observações: ");
		this.Observacoes = input.nextLine();
		
		System.out.println("Cadastro realizado com sucesso.");
		
	}
	
	// Getters e setters para todos os atributos
	public String getNome() {
        return this.Nome;
    }
	
	public void setNome(String nome) {
        this.Nome = nome;
    }
	
	public String getCPF() {
        return this.CPF;
    }
	
	public void setCPF(String cpf) {
        this.CPF = cpf;
    }
	
	public int getIdade() {
		return this.Idade;
	}
	
	public void setIdade(int idade) {
		this.Idade = idade;
	}
	
	public String getTelefone() {
        return this.Telefone;
    }
	
	public void setTelefone(String telefone) {
        this.Telefone = telefone;
    }
	
	public String getEndereco() {
        return this.Endereco;
    }
	
	public void setEndereco(String endereco) {
        this.Endereco = endereco;
    }
	
	public String getEmail() {
        return this.Email;
    }
	
	public void setEmail(String email) {
        this.Email = email;
    }
	
	public String getEscolaridade() {
        return this.Escolaridade;
    }
	
	public void setEscolaridade(String escolaridade) {
        this.Escolaridade = escolaridade;
    }
	
	public String getTituloDeEleitor() {
        return this.TituloDeEleitor;
    }
	
	public void setTituloDeEleitor(String tituloDeEleitor) {
        this.TituloDeEleitor = tituloDeEleitor;
    }
	
	public String getAntecedentes() {
        return this.Antecedentes;
    }
	
	public void setAntecedentes(String antecedentes) {
        this.Antecedentes = antecedentes;
    }
	
	public String getQualificacoes() {
        return this.Qualificacoes;
    }
	
	public void setQualificacoes(String qualificacoes) {
        this.Qualificacoes = qualificacoes;
    }
	
	public String getExperiencia() {
        return this.Experiencia;
    }
	
	public void setExperiencia(String experiencia) {
        this.Experiencia = experiencia;
    }
	
	public double getDisponibilidade() {
		return this.Disponibilidade;
	}
	
	public void setDisponibilidade(double disponibilidade) {
		this.Disponibilidade = disponibilidade;
	}
	
	public int getLimiteDeCriancas() {
		return this.LimitesDeCriancas;
	}
	
	public void setLimiteDeCriancas(int limiteDeCriancas) {
		this.LimitesDeCriancas = limiteDeCriancas;
	}
	
	public String getObservacoes() {
        return this.Observacoes;
    }
	
	public void setObservacoes(String observacoes) {
        this.Observacoes = observacoes;
    }
	
	public String toString() {
		return "\nNome: " + this.Nome + "\nCPF: " + this.CPF + "\nTelefone: " + this.Telefone + "Endereço: " + this.Endereco + "\nEmail: " + this.Email;
	}
	
}
