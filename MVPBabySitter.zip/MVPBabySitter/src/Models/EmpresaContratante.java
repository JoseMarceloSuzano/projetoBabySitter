package Models;

import java.util.ArrayList;
import java.util.Scanner;

public class EmpresaContratante {
	
	private String RazaoSocial;
	private String CNPJ;
	private String Telefone;
	private String Endereco;
	private String Email;
	private int QuantidadeDeMaes;
	private double MediaDeIdadeDasCriancas;

	public EmpresaContratante () {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Razão Social: ");
		this.RazaoSocial = input.nextLine();
		
		System.out.print("CNPJ: ");
		this.CNPJ = input.nextLine();
		
		System.out.print("Telefone: ");
		this.Telefone = input.nextLine();
		
		System.out.print("Endereço: ");
		this.Endereco = input.nextLine();
		
		System.out.print("Email: ");
		this.Email = input.nextLine();
		
		System.out.print("Quantidade de Mães: ");
		this.QuantidadeDeMaes = input.nextInt();
		
		System.out.print("Média de Idade das Crianças: ");
		this.MediaDeIdadeDasCriancas = input.nextDouble();
		
		System.out.println("Cadastro realizado com sucesso.");
		
	}
	
	// Getters e setters para todos os atributos
	public String getRazaoSocial() {
        return this.RazaoSocial;
    }
	
	public void setRazaoSocial(String razaoSocial) {
        this.RazaoSocial = razaoSocial;
    }
	
	public String getCNPJ() {
        return this.CNPJ;
    }
	
	public void setCNPJ(String cnpj) {
        this.CNPJ = cnpj;
    }
	
	public String getTelefone() {
        return this.Telefone;
    }
	
	public void setTelefone(String telefone) {
        this.Telefone = telefone;
    }
	
	public String getEndereco() {
        return this.Endereco;
    }
	
	public void setEndereco(String endereco) {
        this.Endereco = endereco;
    }
	
	public String getEmail() {
        return this.Email;
    }
	
	public void setEmail(String email) {
        this.Email = email;
    }
	
	public int getQuantidadeDeMaes() {
        return this.QuantidadeDeMaes;
    }
	
	public void setQuantidadeDeMaes(int quantidadeDeMaes) {
        this.QuantidadeDeMaes = quantidadeDeMaes;
    }
	
	public double getMediaDeIdadeDasCriancas() {
        return this.MediaDeIdadeDasCriancas;
    }
	
	public void setMediaDeIdadeDasCriancas(double mediaDeIdadeDasCriancas) {
        this.MediaDeIdadeDasCriancas = mediaDeIdadeDasCriancas;
    }
	
	public String toString() {
		return "\nRazão Social: " + this.RazaoSocial + "\nCNPJ: " + this.CNPJ + "\nTelefone: " + this.Telefone + "\nEndereço: " + this.Endereco + "\nEmail: " + this.Email;
	}
	
}
