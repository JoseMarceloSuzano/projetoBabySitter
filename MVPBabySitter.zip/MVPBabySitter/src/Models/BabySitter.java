package Models;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import Service.Contrato;

public class BabySitter {
	
	private double Faturamento; 
	private double Gastos; 
	private ArrayList<String> Balanco;
	
	public BabySitter() {
		Balanco = new ArrayList<>();
	}
	
	public void AdicionarFaturamento(Contrato contrato) {
		this.Faturamento += contrato.getValorTotal();
		Balanco.add("Alocação contratada no valor de: " + contrato.getValorTotal() + " Na data de " + PegarDataAtual());
	}
	
	public void AdicionarGastos() {
		Scanner input = new Scanner(System.in);
		System.out.println("Digite o valor do gasto: ");
		double gasto = input.nextDouble();
		this.Gastos += gasto;
		Balanco.add("Gasto no valor de: " + gasto + " Na data de " + PegarDataAtual());
	}	
	
	public void getBalanco() {
		for (String balanco : Balanco) {
			System.out.println("+---------------------------------------------------------------------------------------------------------------+");
			System.out.println(balanco.toString());
			System.out.println("+---------------------------------------------------------------------------------------------------------------+");
		}
	}
	
	
	public String PegarDataAtual() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String data=dtf.format(now);
      
        return data;
	}
	
}
