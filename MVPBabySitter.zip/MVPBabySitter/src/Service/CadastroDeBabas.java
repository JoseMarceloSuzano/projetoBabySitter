package Service;

import java.util.ArrayList;

import Models.Baba;

public class CadastroDeBabas {

	private ArrayList<Baba> ListaDeBabas;
	
	public CadastroDeBabas() {
		ListaDeBabas = new ArrayList<>();
	}
	
	public void AdicionarBaba (Baba baba) {
		ListaDeBabas.add(baba);
	}
	
	public void getListaDeBabas() {
		for (Baba b : ListaDeBabas) {
			System.out.println("+------------------------------------------------------+");
			System.out.println(("ID: " + ListaDeBabas.indexOf(b)) + b.toString());
			System.out.println("+------------------------------------------------------+\n");
		}
	}

	
}
