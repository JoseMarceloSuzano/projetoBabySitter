package Service;
import Models.EmpresaContratante;
import Models.Baba;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Contrato {
	
	private String DadosDoContrante;
	private double ValorTotal;
	private double TempoDeContrato;
	private int QuantidadeDeBabas;
	private double QuantidadeDeHorasPorDia;
	private String DetalhesDoServico;
	private String ResponsibilidadeDoContratante;
	private String ResponsibilidadeDoContratado;
	private String CondicoesDeRescisao;
	
	public Contrato(EmpresaContratante empresaContratante) {
		Scanner input = new Scanner(System.in);
		
		this.DadosDoContrante = empresaContratante.toString();
		
		System.out.print("Valor Total do Serviço: ");
		this.ValorTotal = input.nextDouble();
		
		System.out.print("Tempo de duração do Contrato em Meses: ");
		this.TempoDeContrato = input.nextDouble();
		
		System.out.print("Quantidade de Babás: ");
		this.QuantidadeDeBabas = input.nextInt();
		
		System.out.print("Quantidade de Horas Necessárias por Dia: ");
		this.QuantidadeDeHorasPorDia = input.nextDouble();
		input.nextLine();
		
		System.out.print("Detalhes do Serviço: ");
		this.DetalhesDoServico = input.nextLine();
		
		System.out.print("Responsibilidades Do Contratante: ");
		this.ResponsibilidadeDoContratante = input.nextLine();
		
		System.out.print("Responsibilidades Do Contratado: ");
		this.ResponsibilidadeDoContratado = input.nextLine();
		
		System.out.print("Condições de Rescisão: ");
		this.CondicoesDeRescisao = input.nextLine();
		
		System.out.println("\nContrato Iniciado Com Sucesso.\n"
						 + "Deseja ver detalhes:\n "
						 + "1- Sim.\n"
						 + "2- Não.");
		int op = input.nextInt();
		
		if (op == 1) {
			System.out.println(toString());
		}
		
	}
	
	public double getValorTotal() {
		return this.ValorTotal;
	}
	
	public String toString() {
		return "+----------------------------------------------------+\n" +
				"Empresa Contratante: \n" +
				"+----------------------------------------------------+\n" +
				this.DadosDoContrante + 
				"\n+----------------------------------------------------+\n" +
				"Dados do Contrato: \n" + 
				this.ValorTotal + "\n" + 
				this.TempoDeContrato + "\n" + 
				this.QuantidadeDeBabas + "\n" +
				this.QuantidadeDeHorasPorDia + "\n" +
				this.DetalhesDoServico + "\n" +
				this.ResponsibilidadeDoContratante + "\n" +
				this.ResponsibilidadeDoContratado + "\n" +
				this.CondicoesDeRescisao + "\n" +
				"+----------------------------------------------------+\n";
	}
	


}
