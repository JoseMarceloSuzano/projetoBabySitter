package Service;

import java.util.ArrayList;

import Models.Equipamentos;

public class CadastroDeEquipamentos {

	private ArrayList<Equipamentos> ListaDeEquipamentos;
	
	public CadastroDeEquipamentos() {
		ListaDeEquipamentos = new ArrayList<>();
	}
	
	public void AdicionarEquipamentos(Equipamentos equipamento) {
		ListaDeEquipamentos.add(equipamento);
	}
	
	public void getListaDeEquipamentos() {
		for (Equipamentos e : ListaDeEquipamentos) {
			System.out.println("+------------------------------------------------------+");
			System.out.println(("ID: " + ListaDeEquipamentos.indexOf(e)) + e.toString());
			System.out.println("+------------------------------------------------------+\n");
		}
	}
}
