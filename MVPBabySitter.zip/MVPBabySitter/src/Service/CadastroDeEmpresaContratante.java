package Service;

import java.util.ArrayList;

import Models.EmpresaContratante;

public class CadastroDeEmpresaContratante {

	private ArrayList<EmpresaContratante> ListaDeEmpresasContratantes;
	
	public CadastroDeEmpresaContratante() {
		ListaDeEmpresasContratantes = new ArrayList<>();
	}
	
	public void AdicionarEmpresaContratante (EmpresaContratante empresa) {
		ListaDeEmpresasContratantes.add(empresa);
	}
	
	public void getListaEmpresas() {
		for (EmpresaContratante e : ListaDeEmpresasContratantes) {
			System.out.println("+------------------------------------------------------+");
			System.out.println(("ID: " + ListaDeEmpresasContratantes.indexOf(e)) + e.toString());
			System.out.println("+------------------------------------------------------+\n");
		}
	}
	
	public EmpresaContratante getEmpresa(int index) {
		return ListaDeEmpresasContratantes.get(index);
	}
	
}
