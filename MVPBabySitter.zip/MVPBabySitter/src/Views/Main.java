package Views;
import java.util.Scanner;

import Models.Baba;
import Models.BabySitter;
import Models.EmpresaContratante;
import Models.Equipamentos;
import Service.CadastroDeBabas;
import Service.CadastroDeEmpresaContratante;
import Service.CadastroDeEquipamentos;
import Service.Contrato;

public class Main {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		CadastroDeBabas cadBaba = new CadastroDeBabas();
		CadastroDeEmpresaContratante cadEmpresa = new CadastroDeEmpresaContratante();
		CadastroDeEquipamentos cadEquipamento = new CadastroDeEquipamentos();
		BabySitter bs1 = new BabySitter();
		
		
		while(true) {			
			 System.out.println("========== BABY SITTER ==========");
		        System.out.println("Bem-vindo(a) ao sistema Baby Sitter!");
		        System.out.println("Por favor, selecione sua opção:");
		        System.out.println("1. Sou uma babá");
		        System.out.println("2. Sou uma empresa contratante");
		        System.out.println("3. Sou um funcionário");
		        System.out.println("4. Sair");

		        System.out.print("\nOpção: ");
		        int opcao = input.nextInt();
		        
		        switch (opcao) {
	            case 1:
	                System.out.println("Realizar Cadastro: ");
		            Baba baba = new Baba();
		            cadBaba.AdicionarBaba(baba);
	                break;
	            case 2:
	                System.out.println("Realizar Cadastro: ");
	                EmpresaContratante empresa = new EmpresaContratante();
	                cadEmpresa.AdicionarEmpresaContratante(empresa);
	                break;
	            case 3:
	            	int op = 1;
	            	do {
		                System.out.println("Qual ação você deseja realizar\n"
               			     + "1- Listar Babás.\n"
               			     + "2- Listar Empresas.\n"
               			     + "3- Adicionar Equipamentos.\n"
               			     + "4- Listar Equipamentos.\n"
               			     + "5- Realizar Contrato.\n"
               			     + "6- Adicionar Gastos.\n"
               			     + "7- Ver financeiro.\n"
               			     + "0- Sair.");
		                
		                op = input.nextInt();
		                
		                switch (op) {
		                case 1:
		                	cadBaba.getListaDeBabas();
		                	break;
		                case 2:
		                	cadEmpresa.getListaEmpresas();
		                	break;
		                case 3:
		                	Equipamentos equipamentos = new Equipamentos();
		                	cadEquipamento.AdicionarEquipamentos(equipamentos);
		                	break;
		                case 4:
		                	cadEquipamento.getListaDeEquipamentos();
		                	break;
		                case 5:
		                	System.out.println("Selecione a empresa contratante: \n");
		                	cadEmpresa.getListaEmpresas();
		                	System.out.print("ID da empresa que será feito o contrato: ");
		                	int id = input.nextInt();
		                	Contrato contrato = new Contrato(cadEmpresa.getEmpresa(id));
		                	bs1.AdicionarFaturamento(contrato);
		                	break;
		                case 6:
		                	bs1.AdicionarGastos();
		                	break;
		                case 7:
		                	bs1.getBalanco();
		                	break;
		                case 0:
		                	System.out.println("Até a proxima :)");
			                break;
		                }
	            	} while(op != 0);              
	        }
		        
		}
		
		
		
	}
}
